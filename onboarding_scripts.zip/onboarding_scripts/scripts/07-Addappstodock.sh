#!/bin/bash
set -x

# Dock Configuration Values
appname="Dock"

# Check if the script has already run
if [[ -f ~/.dock_setup_completed ]]; then
    echo "Dock setup already completed. Exiting."
    exit 0
fi

# Collect Current User Information
currentUser=$( scutil <<< "show State:/Users/ConsoleUser" | awk '/Name :/ { print $3 }' )
uid=$(id -u "${currentUser}")
userHome=$(dscl . -read /users/${currentUser} NFSHomeDirectory | cut -d " " -f 2)
plist="${userHome}/Library/Preferences/com.apple.dock.plist"

# Convenience function to run a command as the current user
runAsUser() {
	if [[ "${currentUser}" != "loginwindow" ]]; then
		launchctl asuser "$uid" sudo -u "${currentUser}" "$@"
	else
		echo "no user logged in"
		exit 1
	fi
}

# Check if dockutil is installed
dockutil="/usr/local/bin/dockutil"
if [[ ! -x "${dockutil}" ]]; then
    echo "dockutil not installed, exiting"
    exit 1
fi

# Version dockutil
echo "Dockutil version = $(${dockutil} --version)"

# Create a clean Dock
runAsUser "${dockutil}" --remove all --no-restart "${plist}"
echo "Cleaned out the Dock"

# Function to update Swift dialog
updateSplashScreen() {
    if [[ -a "/Library/Application Support/Dialog/Dialog.app/Contents/MacOS/Dialog" ]]; then
        echo "$(date) | Updating Swift Dialog monitor for [$appname] to [$1]"
        echo listitem: title: $appname, status: $1, statustext: $2 >> /var/tmp/dialog.log
    fi
}

# Add applications to the Dock under the "Apps" section
apps=(
    "/System/Applications/Launchpad.app"
    "/Applications/Safari.app"
    "/Applications/Microsoft Edge.app"
    "/Applications/Google Chrome.app"
    "/Applications/Firefox.app"
    "/Applications/Microsoft Outlook.app"
    "/Applications/Microsoft Word.app"
    "/Applications/Microsoft Excel.app"
    "/Applications/Microsoft PowerPoint.app"
    "/Applications/Microsoft Teams.app"
    "/Applications/Onedrive.app"
    "/Applications/Microsoft Remote Help.app"
    "/System/Applications/System Settings.app"
)

for app in "${apps[@]}"; do
    runAsUser "${dockutil}" --add "$app" --section apps --no-restart "${plist}"
done

# Add items to the Dock under the "Other" section
runAsUser "${dockutil}" --add "/Applications" --view list --label "Applications" --display stack --sort name --section others --no-restart "/Users/$currentUser"
runAsUser "${dockutil}" --add "~/" --view list --label "Thuismap" --display stack --sort name --section others --no-restart "/Users/$currentUser"
runAsUser "${dockutil}" --add "~/Library/CloudStorage/OneDrive-VariO" --view list --display stack --sort dateadded --section others --no-restart "/Users/$currentUser"
runAsUser "${dockutil}" --add "/Users/$currentUser/Downloads/" --view list --display stack --sort dateadded --section others --no-restart "/Users/$currentUser"

sleep 1

# Setting dock preferences
runAsUser defaults write com.apple.dock show-recents -bool FALSE
runAsUser defaults write com.apple.dock magnification -bool true
runAsUser defaults write com.apple.dock tilesize -int 40
runAsUser defaults write com.apple.dock largesize -float 55

# Apply the changes by restarting the Dock
killall cfprefsd Dock

# Update the Swift dialog screen
updateSplashScreen success "Installed"

# Mark script as completed
touch ~/.dock_setup_completed
echo "Dock setup completed."
